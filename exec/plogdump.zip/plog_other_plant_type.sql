-- MySQL dump 10.13  Distrib 8.0.33, for Win64 (x86_64)
--
-- Host: i11b308.p.ssafy.io    Database: plog
-- ------------------------------------------------------
-- Server version	9.0.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `other_plant_type`
--

DROP TABLE IF EXISTS `other_plant_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `other_plant_type` (
  `other_plant_type_id` bigint NOT NULL AUTO_INCREMENT,
  `plant_name` varchar(255) DEFAULT '',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`other_plant_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `other_plant_type`
--

LOCK TABLES `other_plant_type` WRITE;
/*!40000 ALTER TABLE `other_plant_type` DISABLE KEYS */;
INSERT INTO `other_plant_type` VALUES (1,'Dummy','2024-08-14 02:17:27','2024-08-14 02:17:27'),(2,'콩','2024-08-14 23:40:30','2024-08-14 23:40:30'),(3,'undefined','2024-08-14 23:40:42','2024-08-14 23:40:42'),(4,'특별한 식물','2024-08-15 00:19:34','2024-08-15 00:19:34'),(5,'','2024-08-15 01:03:18','2024-08-15 01:03:18'),(6,'망고','2024-08-15 13:50:24','2024-08-15 13:50:24'),(7,'킥킥','2024-08-15 15:08:28','2024-08-15 15:08:28'),(8,'새로운식물','2024-08-15 15:35:20','2024-08-15 15:35:20'),(9,'새롭다','2024-08-15 15:39:16','2024-08-15 15:39:16'),(10,'정말긴식물이름','2024-08-15 15:44:18','2024-08-15 15:44:18'),(11,'정말긴식물이름정말길다정말로','2024-08-15 15:44:33','2024-08-15 15:44:33'),(12,'정말긴식물이름정말길다정말로이거어디까지길어지는거에요','2024-08-15 15:45:01','2024-08-15 15:45:01'),(13,'매실','2024-08-15 16:24:00','2024-08-15 16:24:00'),(14,'납짝선인장','2024-08-15 18:16:04','2024-08-15 18:16:04');
/*!40000 ALTER TABLE `other_plant_type` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-08-16  5:51:00
