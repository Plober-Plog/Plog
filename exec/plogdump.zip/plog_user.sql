-- MySQL dump 10.13  Distrib 8.0.33, for Win64 (x86_64)
--
-- Host: i11b308.p.ssafy.io    Database: plog
-- ------------------------------------------------------
-- Server version	9.0.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user` (
  `user_id` bigint NOT NULL AUTO_INCREMENT,
  `search_id` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `nickname` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `image_id` bigint DEFAULT NULL,
  `birth_date` date DEFAULT NULL,
  `is_ad` tinyint(1) DEFAULT '0',
  `total_exp` int NOT NULL DEFAULT '0',
  `profile_info` varchar(255) DEFAULT '글을 남겨주세요.',
  `source` varchar(255) DEFAULT NULL,
  `chat_auth` int NOT NULL DEFAULT '1',
  `gender` int NOT NULL DEFAULT '1',
  `provider_id` varchar(255) DEFAULT NULL,
  `provider` int DEFAULT NULL,
  `role` int NOT NULL DEFAULT '1',
  `state` int NOT NULL DEFAULT '1',
  `sido_code` int DEFAULT NULL,
  `gugun_code` int DEFAULT NULL,
  `notification_token` varchar(255) DEFAULT NULL,
  `is_push_notification_enabled` tinyint(1) DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`user_id`),
  KEY `image_id` (`image_id`),
  CONSTRAINT `user_ibfk_1` FOREIGN KEY (`image_id`) REFERENCES `image` (`image_id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (1,'c4526','c4526@naver.com','토마토광인','$2a$10$50IpTE94/du9UCVvhV2XtOZZpJfUajwzWCmOasKun6t.7r3TN1zVm',851,NULL,0,0,'안녕하세용가리','',1,3,NULL,0,1,1,3,4,'fLU2jTQVIJaZ6OtDP82KDZ:APA91bGaI1a-IxdjuF4JvDlU67UmZhVxOqhKHRoVbu_ws2jfx12QCVlSasqGjhK42zP30jyhPriJF_oPl6NqU3pwfJpSRXwOhcF7ZqPeOKiZWMkZULbMLBN2ZNTJHeuxPb1QbpqBi3xy',1,'2024-08-14 11:19:17','2024-08-16 02:38:27'),(2,'plober','zpqmdh@naver.com','플로버','$2a$10$6X0EtAiJH2.sjPkS8MUfROM2k0gzJoLsfmQxNzgslAWQPjAL3GjHq',581,NULL,0,0,'안녕하세요.','',1,1,NULL,0,1,1,3,4,'efQ1K5Ayl_2oGyUQtmEJo2:APA91bG-J82X4T_Q8HY0S3tdRuDaIOWK_SvizGimaEMYI6hnGDmBL7lSf21SHBmV5i4tXwpgsweg5ZDHwOcVwha4mNCIXlcnbieDVm4KEYU5nmRlc63h0zbJvltqQhIXvfWobYN2Xve3',1,'2024-08-14 11:20:53','2024-08-16 04:26:41'),(3,'gapple95','gapple95@naver.com','gapple','$2a$10$AkeDzpv7qUclJFYfpIyCjumbWcibtGVFzjJ/0/5/rtuWW6zTuZcbO',582,NULL,0,0,'안녕하세요.','',1,2,NULL,0,1,1,3,4,NULL,0,'2024-08-14 12:15:31','2024-08-15 00:08:09'),(4,'zpqmdh','ysys1130@gmail.com','식물집사','$2a$10$10at/jZIkrTVwZxeytXnPeXQgJy99IrpXy5UvqJFslIsHJJYaAmfy',584,'2001-11-30',0,0,'안녕하세요.','',1,3,NULL,0,1,1,35,23,NULL,0,'2024-08-14 12:37:06','2024-08-15 15:59:42'),(5,'ckdbfla','cc45267@gmail.com','용용이','$2a$10$ny8hiMXs8VTHSyBbUiJ3s.QNkTAmKkxjkuXdNXCmSiiqhp7QE.QdC',624,NULL,0,0,'안녕하세요.','',1,3,NULL,0,1,2,33,7,'d7wx7CsmQ_mHkcrBmR2zjp:APA91bEDI4pcoDdnF_9_ETA0v9CrjZUqzix55IV-s3765TG7ZD9mC67bGtLsoWi7hMr61LfihE7rGkX6FrZ6PBKUax6iCWhYbYnVxqT-ExRxz5pTncPOVedV66FnnuZcyO6J1PXeCbLm',0,'2024-08-14 12:54:59','2024-08-14 11:32:44'),(6,'dlduddnjs198','dlduddnjs198@naver.com','흰둥이','$2a$10$qnqN5QVeIQ.MUX3J/77/x.3RZ/Lht5eo7u6bHDXIwKHwVrHZrLhvO',674,NULL,0,0,'안녕하세용ㅎㅋ','',1,2,NULL,0,1,1,34,11,NULL,0,'2024-08-14 13:36:21','2024-08-15 15:52:38'),(7,'cc4526','youl125@naver.com','조이차','$2a$10$OZD0kAQYYWl61GMRPZY52eZeP/1XDdHPRQUX3b6V75/WqoOIKJ2Ai',628,'2024-08-12',0,0,'안녕하세요.','',1,3,NULL,0,1,1,31,31,NULL,0,'2024-08-14 14:50:49','2024-08-14 11:32:44'),(8,'wkdguswns100','wkdguswns100@naver.com','장현준','$2a$10$vxc8/KPWhF0TvLDvxScYkuaSauHuc94TF9wxbwl40E53lCEO4H.oK',630,'1995-10-02',0,0,'안녕하세요.','',1,2,NULL,0,1,1,3,4,NULL,0,'2024-08-14 14:51:26','2024-08-15 00:15:44'),(9,'testtes3','ay8160@daum.net','콩심은데콩나','$2a$10$mHsOnhDUlGPLnzK35/qvG.XsB4bt6WT88h/8RBZUFFEAzVHLhaB2m',719,NULL,0,0,'전데요?!','',1,3,NULL,0,1,1,32,8,NULL,1,'2024-08-14 14:57:02','2024-08-15 23:44:13'),(10,'qwerty1234','racoma2309@chaladas.com','쿼티1234','$2a$10$3aUDGoRsFvhNeprflrU68eAptJF.5olQvQqK9ikCzlbAUSIx/w31e',639,'2024-08-14',0,0,'안녕하세요.','',1,3,NULL,0,1,1,36,12,NULL,0,'2024-08-14 15:12:14','2024-08-14 11:32:44'),(11,'chacha','ssafyayl@gmail.com','조이차','$2a$10$fJnKFdSgyrkKPCWES8o1BeV4wB.ohxRiEfRERC20DsPpzorw/06eS',643,'2024-08-15',0,0,'안녕하세요.','',1,3,NULL,0,1,1,31,30,NULL,0,'2024-08-14 15:21:17','2024-08-14 11:32:44'),(12,'qwerty4321','jasik43878@segichen.com','Qwerty','$2a$10$3RfRdmimd2fAMKm9t4mjG.9iY3n/6d6N9hY9FTXKpDlYOojAKxRHW',646,'2024-08-14',0,0,'안녕하세요.','',1,1,NULL,0,1,1,0,0,NULL,0,'2024-08-14 15:45:19','2024-08-14 11:32:44'),(13,'ckckck','uuulimi@daum.net','차차차','$2a$10$hXkcP4dS6cWQN/jFEYEYG.c5tCN2A7fzfoHFeJJsv0XHFivJmBoUa',679,'2024-08-13',0,0,'안녕하세요.','',1,3,NULL,0,1,1,0,0,NULL,0,'2024-08-14 17:36:45','2024-08-14 11:32:44'),(14,'qwerty0987','becen47881@brinkc.com','qwerty','$2a$10$UXGTL4KM4VG5IDrMkArblu1oUuTZDAMfyXrUtWhRmYmohnsv4fnJe',693,NULL,0,0,'안녕하세용','',1,3,NULL,0,1,1,0,0,'fr3-X6Hsuf0QCGo0uJe4mn:APA91bHToWUZ9VqzbC6CYrt_4R9Xm0f846QfIOtmkBhCxxA81q9Nj0uLnrHu0yYg3gpj2pDfhYoN6ru_1dC1ByJy6rgcpC6lPJ4qEQLJctXVop8NQj2lVQFgJk46FN-VeVp7py5o4a2D',0,'2024-08-14 20:37:29','2024-08-14 20:46:45'),(15,'inputoutput','ay9812@gmail.com','팥심은데팥나','$2a$10$RCW4ZGpjlz2ENIs3ldCPGu7VZjTlnM8uLnS76KGgDj.cpSaUwMNHC',702,NULL,0,0,'안녕하세요!','',1,3,NULL,0,1,1,0,0,NULL,0,'2024-08-14 22:55:33','2024-08-14 22:59:00'),(16,'ssafy.gapple95G','ssafy.gapple95@gmail.com','ssafy.gapple95G','oauth2',709,NULL,0,0,NULL,NULL,1,1,'100593335149048985991',1,1,1,0,0,NULL,1,'2024-08-15 00:15:46','2024-08-15 00:15:46'),(17,'farmer','jinao1207@naver.com','농부부','$2a$10$YAHhgBaEjN9K1rwPJaL.1O9JVEe8oE91RCOGAotlMkysMG7NyWOo.',721,NULL,0,0,'안녕하세요!','',1,3,NULL,0,1,1,0,0,NULL,0,'2024-08-15 00:45:34','2024-08-15 00:46:09'),(18,'dmddorns','dmddorns61@gmail.com','성현추','$2a$10$s9x1AAo4pDw280WPanhmVOX05jqfPUNZCzyfjFvlrTR2LMKfQH5J6',726,'1999-09-19',0,0,'안녕하세요!','',1,2,NULL,0,1,1,32,3,NULL,0,'2024-08-15 04:38:20','2024-08-15 04:38:20'),(19,'plog123','dlduddnjs4798@gmail.com','파랑이','$2a$10$Jt9pJoDmzQPFy72csZxLreSJBFrzyrdMO5jyMDi9x6wbywQSBQyP.',759,NULL,0,0,'안녕하세요! 식물 초보집사 파랑이입니다~!','',1,2,NULL,0,1,1,3,4,'c4HMOPDqx9Cb3nXf0dasHv:APA91bGPqLLHpn3mAHoQ5WyCxeoPclc5k531AQ5H4LXieBgClwXM6fgxa4YUFg2SPJpUIj1A-pcbI2aLVjnPzpXdRAdc6BeQjA-qamhfxRv0iQh4HDDo_YmheesSPLwgnC6g4fAiuZrG',1,'2024-08-15 15:54:17','2024-08-15 17:52:18'),(20,'helloworld','liwehi6376@segichen.com','헬로월드','$2a$10$Ld/7sevf13MdI0DIDoealepHJ.TGb1IFhved8m6YoffsQ7C.0I9MO',787,NULL,0,0,'안녕하세요!','',1,3,NULL,0,1,1,3,4,NULL,0,'2024-08-15 18:07:40','2024-08-15 18:20:49'),(21,'hslee0912G','hslee0912@gmail.com','hslee0912G','oauth2',837,NULL,0,0,NULL,NULL,1,1,'116633631567389500997',1,1,1,0,0,NULL,1,'2024-08-15 21:40:28','2024-08-15 21:40:28'),(22,'hslee0912','hslee0912@naver.com','Hslee','$2a$10$FcTh1pUha.5X9pGtzOnbxOtH.3RyizA3bzyFgtGMIcYkG6Cn7a3ky',842,'2024-08-12',0,0,'안녕하세요!','',1,2,NULL,0,1,1,3,4,'cZZnPjb6y2TEZ3cLXGh4JX:APA91bGPyTTScItsnDWPu1s5TgMR_QNQZsBl9araDpBRQc8CXwPTTYCVkY24iiHpWLusVhscEtRLptLcag9C8ba5T2YJnOnI16KIfBKEDBtzmnMdqw4mz0c5GIKqRrOdGSzVj_ObvNaR',1,'2024-08-16 00:20:44','2024-08-15 15:37:24');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-08-16  5:50:55
